<?php

// Read the key and path_for_save from the config file
$configFile = ":config.json";
$configData = json_decode(file_get_contents($configFile), true);

$key_from_file = $configData["key"];
$path_for_save = $configData["path_for_save"];

if (($body_stream = file_get_contents("php://input")) === FALSE) {
    echo "Bad Request";
    exit;
}

$data = json_decode($body_stream, TRUE);

// Compare the key in the data with the key from the config file
if ($data["key"] !== $key_from_file) {
    echo "Invalid Key";
    exit;
}

if ($data["status"] == 2) {
    $downloadUri = $data["url"];

    if (($new_data = file_get_contents($downloadUri)) === FALSE) {
        echo "Bad Response";
    } else {
        file_put_contents($path_for_save, $new_data, LOCK_EX);
    }
}

echo "{\"error\":0}";
?>

