import json
import aiofiles

async def readjson(filename, mode='r', encoding='utf-8'):
    async with aiofiles.open(filename, mode=mode, encoding=encoding) as file:
        data = await file.read()
        json_data = json.loads(data)
        return json_data
    
async def writejson(filename, data, mode='w', encoding='utf-8'):
    async with aiofiles.open(filename, mode=mode, encoding=encoding) as file:
        json_data = json.dumps(data, indent=4)
        await file.write(json_data)
        return json_data
    
def readjson_sync(filename, mode='r', encoding='utf-8'):
    with open(filename, mode=mode, encoding=encoding) as file:
        data = file.read()
        json_data = json.loads(data)
        return json_data
    
def writejson_sync(filename, data, mode='w',indent=2, encoding='utf-8'):
    with open(filename, mode=mode, encoding=encoding) as file:
        json_data = json.dumps(data, indent=indent)
        file.write(json_data)
        return json_data