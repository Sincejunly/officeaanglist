import asyncio
import json
import aiomysql
import pymysql


class AsyncMysqlPool(aiomysql.pool.Pool):
    def __init__(self, minsize=1, maxsize=10, echo=False, pool_recycle=3600,**kwargs):
        super().__init__(minsize, maxsize, echo, pool_recycle, **kwargs)

    def type_columns(self,col):
        length = ""

        if isinstance(col, int):
            Dtype = "INT"
        elif isinstance(col, str):
            Dtype = "VARCHAR"
            length = "({})".format(len(col) + 100 if len(col) > 0 else 255)
        elif isinstance(col, float):
            Dtype = "FLOAT"
        elif isinstance(col, bool):
            Dtype = "BOOLEAN"
        elif (isinstance(col, list) and len(col) <= 1) or isinstance(col, dict):
            Dtype = "JSON"
        elif isinstance(col, list) and len(col) > 1:
            Dtype = col[1]
       
        return f"{Dtype}{length}" if length else Dtype    
    
    async def find_longest(self,data):
        # Get the number of columns
        num_columns = len(data[0])

        # Initialize a list to store the longest elements for each column
        longest_elements = ["" for _ in range(num_columns)]

        # Iterate through the data to find the longest elements in each column
        for row in data[1:]:
            for col_index, element in enumerate(row):
                if len(str(element)) > len(str(longest_elements[col_index])) or isinstance(element, list):
                    longest_elements[col_index] = element

        return longest_elements
    
    async def turnToList(self, data):
        # Convert the dictionary keys to a tuple and store it as the first element of the list
        database_list = [tuple(data.keys())]

        # Convert the dictionary values to a tuple and append it to the list
        database_list.append(tuple(data.values()))

        return database_list
    
    async def create_table(self, table, columns, columns1, cursor=None):
        # create_table_query = f'CREATE TABLE IF NOT EXISTS {table} \
        #     ({columns[0]} {columns1[0][1] if isinstance(columns[0], list) else self.type_columns(columns[0])} NOT NULL, PRIMARY KEY ({columns[0]}), \
        #     {", ".join(f"{col} {val[1] if isinstance(val, list) else self.type_columns(val)} NOT NULL" for col, val in zip(columns[1:], columns1[1:]))})'
        

        if '`id`' in columns:
            create_table_query = f'CREATE TABLE IF NOT EXISTS {table} \
            (`id` INT AUTO_INCREMENT, PRIMARY KEY (`id`), \
            {", ".join(f"{col} {self.type_columns(val)} " for col, val in zip(columns[1:], columns1[1:]))}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;'
        else:
            create_table_query = f'CREATE TABLE IF NOT EXISTS {table} \
                ({columns[0]} {self.type_columns(columns1[0])} ,PRIMARY KEY ({columns[0]}), \
                {", ".join(f"{col} {self.type_columns(val)}" for col, val in zip(columns[1:], columns1[1:]))}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;'

        if not cursor:
            async with self.acquire() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute(create_table_query)
            affected_rows = cursor.rowcount
            return affected_rows
        else:
            await cursor.execute(create_table_query)
        

    async def get_existing_columns(self, cursor, table):
        await cursor.execute("SHOW COLUMNS FROM {}".format(table))
        columns = [column_info[0] for column_info in await cursor.fetchall()]
        return columns
    
    async def get_existing_columns(self, cursor, table):
        await cursor.execute("SHOW COLUMNS FROM {}".format(table))
        columns = [column_info[0] for column_info in await cursor.fetchall()]
        return columns

    async def process_tuple(self, tuple_data):
        processed_data = []
        for item in tuple_data:
            if isinstance(item, dict):
                if len(item)==0:
                    processed_data.append('')
                else:
                    processed_data.append(json.dumps(item))
            elif isinstance(item, list):
                if len(item)==0:
                    processed_data.append('')
                else:
                    processed_data.append(json.dumps(item))
            else:
                processed_data.append(item)

        return tuple(processed_data)
    
    async def update(self, table, userData, overwrite=False):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                if isinstance(userData, dict):
                    userData = await self.turnToList(userData)
                columns = userData[0]  # Get the column names from the first tuple in userData
                values = userData[1:]  # Get the data rows (excluding the first tuple)
                lon = await self.find_longest(userData)
                await self.create_table(table, columns, tuple(lon), cursor)  # Assuming create_table is a method to create the table if it doesn't exist

                for line in values:
                    
                    line = await self.process_tuple(line)
                    #print('line:')
                    #print(line)
                    select_query = f"SELECT COUNT(*) FROM {table} WHERE {columns[0]} = %s"
                    
                    await cursor.execute(select_query, (line[0],))

                    result = await cursor.fetchone()

                    if result[0] > 0:
                        if overwrite:
                            update_query = f"UPDATE {table} SET {', '.join([f'{column} = %s' for column in columns[1:]])} WHERE {columns[0]} = %s"
                            await cursor.execute(update_query, tuple(line[1:]) + (line[0],))
                        else:
                            continue
                    else:
                        
                        insert_query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(['%s'] * len(columns))})"
                        #print(insert_query,line)
                        await cursor.execute(insert_query, line)

                affected_rows = cursor.rowcount
                return affected_rows
            
    async def update_value(self,table, columnName, columnValue, valueName, value,):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                try:
                    await cursor.execute(f"UPDATE {table} SET {valueName} = %s WHERE {columnName} = %s", (value, columnValue))
                except pymysql.err.ProgrammingError:
                    return None
    
    async def getMaxid(self, table):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                try:
                    await cursor.execute(f"SELECT MAX(id) FROM {table}")
                    result = await cursor.fetchone()
                    return result[0]
                except pymysql.err.ProgrammingError:
                    return None
                
    async def delete_row(self, table, column, value):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                try:
                    await cursor.execute(f"DELETE FROM {table} WHERE {column} = %s", (value,))
                except pymysql.err.ProgrammingError:
                    return None

    async def is_table_empty(self, table):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                try:
                    await cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    result = await cursor.fetchone()
                    return result[0] == 0
                except pymysql.err.ProgrammingError:
                    return True
                
    async def commd(self, commd):
        async with self.acquire() as conn:
            async with conn.cursor() as cursor:
                try:
                    await cursor.execute(commd)
                except pymysql.err.ProgrammingError:
                    return None
                
    async def get_value_by_value(self, table, column, value, columN):
        async with self.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cursor:
                try:
                    await cursor.execute(f"SELECT {columN} FROM {table} WHERE {column} = %s", (value,))
                    result = await cursor.fetchone()
                    return result
                except pymysql.err.ProgrammingError:
                    return None
        
    async def get_row_by_value(self, table, column, value):
        async with self.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cursor:
                try:
                    await cursor.execute(f"SELECT * FROM {table} WHERE {column} = %s", (value,))
                    result = await cursor.fetchone()
                    return result
                except pymysql.err.ProgrammingError:
                    return None
                
    async def getAllrow(self, table):
        async with self.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cursor:
                try:
                    await cursor.execute(f"SELECT * FROM {table}")
                    result = await cursor.fetchall()
                    return result
                except pymysql.err.ProgrammingError:
                    return None

    @classmethod
    async def create(cls, loop, **kwargs):
        pool = cls(loop=loop, **kwargs)
        #await pool.init_pool()
        return pool

    @classmethod
    async def initialize_pool(cls, host, port, user, password, db,minsize=1, maxsize=10, echo=False, pool_recycle=3600):
        pool = await cls.create(
            loop=asyncio.get_event_loop(),
            host=host,
            port=port,
            user=user,
            password=password,
            db=db,
            autocommit=True,
            minsize=minsize,
            maxsize=maxsize, 
            echo=echo, 
            pool_recycle=pool_recycle,
        )
        return pool
